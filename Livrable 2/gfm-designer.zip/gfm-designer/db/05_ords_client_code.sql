--------------------------------------------------------------------------------
-- GFM Designer - OAuth2 client for the authorization code flow
--
-- Recent ORDS releases disable the implicit flow ("response_type=token
-- n'est pas autorisé"): the web client uses the authorization code flow.
--
-- Run as the schema that owns module gfm.designer, after 04_ords_security.sql
-- (role gfm_designer and privilege gfm.designer.priv must exist).
-- SET SERVEROUTPUT ON: the client_id and the generated client_secret are
-- printed once. The secret is not stored in readable form: copy it into
-- client/js/config.js (clientSecret) right away.
--
-- Edit the variables below:
--   c_origin       : origin of the web client (scheme://host:port)
--   c_redirect_uri : URL of index.html of the web client
--------------------------------------------------------------------------------
set serveroutput on
set define off

declare
    c_name          constant varchar2(30)  := 'gfm_designer_web';
    c_origin        constant varchar2(500) := 'http://localhost:8080';
    c_redirect_uri  constant varchar2(500) := 'http://localhost:8080/index.html';
    c_support_email constant varchar2(200) := 'support@example.com';
    c_support_uri   constant varchar2(500) := 'http://localhost:8080/';

    l_cred  ords_types.t_client_credentials;
    l_count pls_integer;
begin
    select count(*) into l_count from user_ords_clients where name = c_name;

    if l_count = 0 then
        l_cred := ords_security.register_client(
            p_schema          => user,
            p_name            => c_name,
            p_grant_type      => 'authorization_code',
            p_support_email   => c_support_email,
            p_description     => 'Client web GFM Designer (authorization code)',
            p_privilege_names => 'gfm.designer.priv',
            p_origins_allowed => c_origin,          -- CORS of the token endpoint
            p_redirect_uri    => c_redirect_uri,
            p_support_uri     => c_support_uri );
    end if;

    -- new secret (the client already exists: the previous secrets are revoked)
    l_cred := ords_security.rotate_client_secret(
        p_schema          => user,
        p_client_key      => ords_types.t_client_key(name => c_name),
        p_revoke_existing => true );
    commit;

    dbms_output.put_line('clientId     : ' || l_cred.client_key.client_id);
    dbms_output.put_line('clientSecret : ' || l_cred.client_secret.secret);
end;
/

-- The implicit client is no longer used:
-- begin oauth.delete_client('gfm_designer_spa'); commit; end;
-- /
